const Marketing = [
  
    {
      id: 1,
      name: 'Marketing',
  
      category1: 'Campaign',
      category2: 'Vouchers', 
      category3: 'Discount Promotions',
      category4: 'Bundle Deals',
      category5: 'Add on  Deals',
      category6: 'Shipping Free Promotion',
      category7: 'Myshops Flash Deals',
      category8: 'Follow up Price',
      category9: 'Zmall Ads',
      
      category10: 'Top Picks', 
      image1: require('../assets/images/Campaign.png'),
      image2: require('../assets/images/voucher.png'),
      image3: require('../assets/images/pro64.png'),
      image4: require('../assets/images/pro64.png'),
      
      image5: require('../assets/images/pro64.png'),
      
      image6: require('../assets/images/Freeshipping.png'),
      
      image7: require('../assets/images/pro64.png'),
      
      image8: require('../assets/images/pro64.png')
      ,
      image9: require('../assets/images/pro64.png')
      ,
      image10: require('../assets/images/pro64.png'),
      
      
      
    },
     
  ];

  export default Marketing;