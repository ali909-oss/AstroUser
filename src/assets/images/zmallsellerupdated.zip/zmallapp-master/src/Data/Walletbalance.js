export const WalletBalance = [
    {
           id:1,
           balance:"$ 220"
    }
]