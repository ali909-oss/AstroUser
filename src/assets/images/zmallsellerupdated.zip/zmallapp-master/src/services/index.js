import StaticImageService from './StaticImageService';
import AuthenicationService from './AuthenticationService';

export {StaticImageService, AuthenicationService};
