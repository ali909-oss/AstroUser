import React from 'react'
import { View, Text } from 'react-native'
import Bundledealspromotion from './Bundledealspromotion'
import DiscountPromotions from './DiscountPromotions' 
import VoucherPromotions from './VoucherPromotions'
import Voucherscomp from './Voucherscomp'

const Allpromotionsb = () => {
    return (
        
            
    <Bundledealspromotion/> 
         
    )
}

export default Allpromotionsb
