import React from 'react'
import { View, Text } from 'react-native'  
import DiscountPromotionsmain from './DiscountPromotionsmain'
import VoucherPromotions from './VoucherPromotions'
import Voucherscomp from './Voucherscomp'
import DiscountPromotions from './DiscountPromotions'

const Allpromotionsd = () => {
    return (
        
            
    <DiscountPromotions/> 
         
    )
}

export default Allpromotionsd
