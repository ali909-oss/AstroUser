import React, { Component } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { Table, TableWrapper, Row } from 'react-native-table-component';
import Voucherscomp from './Voucherscomp';


import { heightPercentageToDP } from 'react-native-responsive-screen' 
import Adddiscount from './Adddiscount';
import Discountcomp from './Discountcomp';
export default class DiscountPromotions extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tableHead: ["Promotion Code Name","Promotion Type","Discount Type","Discount Percentage","Starting Date","Ending Date","Usage Limit","Claimed","Usage","Status"],
      widthArr: [180, 160, 160, 160, 140, 140, 120, 120, 120,120]
    }
  }
 
  render() {
    const state = this.state;
    const tableData = [];
    
 
    return (
      <View style={styles.container}>
        <ScrollView horizontal={true} showsHorizontalScrollIndicator = {false}>
          <View>
            <Table>
              <Row data={state.tableHead} widthArr={state.widthArr} style={styles.header} textStyle={styles.text}/>
            </Table>
            <ScrollView style={styles.dataWrapper}>
              <Table borderStyle={{borderWidth: 1, borderColor: 'grey'}}>
                {
                  tableData.map((rowData, index) => (
                    <Row
                      key={index}
                      data={rowData}
                      widthArr={state.widthArr}
                      style={[styles.row, index%2 && {backgroundColor: '#ffffff'}]}
                      textStyle={styles.text}
                    />
                  ))
                }
              </Table>
            </ScrollView>
          </View>
        </ScrollView> 
        
        <Discountcomp/>
      </View>
    )
  }
}
 
const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 10,height:heightPercentageToDP("50%")},
  header: { height: 50},
  text: { textAlign: 'center',color:"black" },
  dataWrapper: { marginTop: -1 },
  row: { height: 40, backgroundColor: '#ffffff' }
});