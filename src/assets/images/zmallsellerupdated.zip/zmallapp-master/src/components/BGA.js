import { View, Text } from 'react-native';
import React from 'react';

const BGA = () => {
  return (
    <View>
      <Text></Text>
    </View>
  );
};

export default BGA;
