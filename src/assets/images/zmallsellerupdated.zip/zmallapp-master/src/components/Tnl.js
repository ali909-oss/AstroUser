import { View, Text } from 'react-native';
import React from 'react';

const Tnl = () => {
  return (
    <View>
      <Text></Text>
    </View>
  );
};

export default Tnl;
