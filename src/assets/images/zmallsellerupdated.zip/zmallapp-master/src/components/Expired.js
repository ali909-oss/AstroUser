import React from 'react'
import { View, Text,Image} from 'react-native'
import { heightPercentageToDP } from 'react-native-responsive-screen'
import OrdersButton from './Voucherbutton'
import Voucherscomp from './Voucherscomp'

const Expired = () => {
    return (
       <Voucherscomp/>
    )
}

export default Expired
