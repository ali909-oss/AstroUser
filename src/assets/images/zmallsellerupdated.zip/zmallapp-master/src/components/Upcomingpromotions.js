import React from 'react'
import { View, Text } from 'react-native'
import DiscountPromotions from './DiscountPromotions' 
import VoucherPromotions from './VoucherPromotions'
const Upcomingpromotions = () => {
    return (
        
       <VoucherPromotions/>
    )
}

export default Upcomingpromotions
