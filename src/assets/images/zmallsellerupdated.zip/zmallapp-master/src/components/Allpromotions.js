import React from 'react'
import { View, Text } from 'react-native'
import DiscountPromotions from './DiscountPromotions' 
import VoucherPromotions from './VoucherPromotions'
import Voucherscomp from './Voucherscomp'

const Allpromotions = () => {
    return (
        
            
    <VoucherPromotions/> 
         
    )
}

export default Allpromotions
