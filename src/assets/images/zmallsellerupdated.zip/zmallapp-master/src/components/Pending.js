import React from 'react'
import { View, Text } from 'react-native'

const Pending = () => {
    return (
        <View style = {{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Pending</Text>
        </View>
    )
}

export default Pending
