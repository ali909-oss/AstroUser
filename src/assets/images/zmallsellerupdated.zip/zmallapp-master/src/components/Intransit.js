import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {Fonts} from '../contants';

import Iconsetting from 'react-native-vector-icons/AntDesign';
import Orderstooltip from './Orderstooltip';
const Intransit = () => {
  return <Orderstooltip />;
};

export default Intransit;
