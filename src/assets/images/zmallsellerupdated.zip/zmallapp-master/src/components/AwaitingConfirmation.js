import React from 'react';
import {View, Text,StyleSheet,Image} from 'react-native'; 
import { Fonts } from '../contants';
import {heightPercentageToDP, widthPercentageToDP} from 'react-native-responsive-screen';
import Iconsetting from 'react-native-vector-icons/AntDesign';
import Orderstooltip from './Orderstooltip';
import axios from 'axios'
import { useEffect,useState } from 'react';
const AwaitingConfirmation = () => {
  const [orders , setOrders] = useState([])
  const url = 'https://zmallapi.herokuapp.com/api/v1/orders/vendor/364'
  useState(()=>{
    const api = async () => {
      const result = axios.get(url)
      setOrders(result.data)
    }
    api()

  },[])
  console.log(orders)
  return ( 
    <View>
    <View style = {{height:heightPercentageToDP("7%"),backgroundColor:"white"}}>
       <Orderstooltip name = "Awaiting Confirmation"/></View>
       <Text>Order No</Text>
       
       
       </View>
  
 );
}; 
export default AwaitingConfirmation;
