import React from 'react'
import { View, Text } from 'react-native'
import DiscountPromotions from './DiscountPromotions' 
const Ongoingpromotionsd = () => {
    return (
       
        <DiscountPromotions/>
    )
}

export default Ongoingpromotionsd
