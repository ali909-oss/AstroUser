import React from 'react'
import { View, Text } from 'react-native'
import Swapcards from './Swapcards'

const Swapfunc = () => {
    return (
        <View style = {{flex:1,backgroundColor:"white"}}>
            <Swapcards/>
        </View>
    )
}

export default Swapfunc
