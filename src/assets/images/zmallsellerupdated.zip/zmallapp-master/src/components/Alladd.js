import React from 'react'
import { View, Text,StyleSheet,TouchableOpacity } from 'react-native'  

import {Fonts} from '../contants';

import {heightPercentageToDP, widthPercentageToDP} from 'react-native-responsive-screen';
import OrdersButton from './Voucherbutton';
import Voucherscomp from './Voucherscomp';
import Addonpromotions from './Addonpromotions';
const Alladd = () => {
    return (
        <Addonpromotions/>
    )
}

 
export default Alladd;
