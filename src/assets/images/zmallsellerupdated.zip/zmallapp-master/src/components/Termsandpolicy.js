import React from 'react'
import { View, Text } from 'react-native'

const Termsandpolicy = () => {
    return (
        <View style = {{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Terms and Policy</Text>
        </View>
    )
}

export default Termsandpolicy
