import React from 'react'
import { View, Text } from 'react-native'

const SetStatusfunc = () => {
    return (
        <View>
            <Text>
                 
            </Text>
        </View>
    )
}

export default SetStatusfunc
