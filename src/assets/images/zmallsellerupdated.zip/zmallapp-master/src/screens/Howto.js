import React from 'react'
import { View, Text } from 'react-native'

const Howto = () => {
    return (
        <View style = {{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text> Coming Soon ! </Text>
        </View>
    )
}

export default Howto
