import React from 'react'
import { View, Text } from 'react-native'

const Feedscreen = () => {
    return (
        <View>
            <Text>Hello</Text>
        </View>
    )
}

export default Feedscreen
