Finance = [
  
    {
      id: 1,
      name: 'Finance',
  
      category1: 'Bank Account',
      category2: 'Account Statement', 
      category3: 'Transaction Overview',
      image1: require('../assets/images/Campaign.png'),
      image2: require('../assets/images/voucher.png'),
      image3: require('../assets/images/pro64.png'),
    
      
      
    },
     
  ];

  export default Finance;