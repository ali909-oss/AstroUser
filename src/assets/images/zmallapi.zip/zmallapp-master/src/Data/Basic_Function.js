const Basic_Function = [
  
  {
    id: 1,
    name: 'Basic Function',

    category1: 'Manage Reviews',
    category2: 'Add Products', 
    category3: 'Orders',
    category4: 'Products',
    image1: require('../assets/images/Managereviews.png'),
    image2: require('../assets/images/Addproducts.png'),
    image3: require('../assets/images/Orders.png'),
    image4: require('../assets/images/Products.png')
    
  },
   
];


 
export default Basic_Function;
