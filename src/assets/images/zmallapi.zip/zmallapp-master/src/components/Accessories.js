import React, {useState} from 'react';
import {View, Text, StyleSheet, Image, ScrollView} from 'react-native';
import {TextInput, TouchableOpacity} from 'react-native-gesture-handler';
import DynamicForm from '@coffeebeanslabs/react-native-form-builder';
import {Belt,Bracelet,Cufflinks,Fragrance,HatsandCaps,PocketSquare,Rings,Socks,Ties,Glasses } from "../Data/Formdata" 
 import {
  Select,
  VStack,
  CheckIcon,
  Center,
  NativeBaseProvider,
} from 'native-base';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import Contactus from './Contactus';
import Termsandpolicy from './Termsandpolicy';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {Colors, Fonts} from '../contants';
import Help from './Help';
import SellerAccount from './SellerAccount';
import Businessinfo from './Businessinfo';
import Address from './Address';
import Returnaddress from './Returnaddress';
 
 
const onSubmit = formFields => {
  // Actions on submit button click.
  console.log('Form submitted with fields: ', formFields.birthDate.value);
};
const Accessories = () => {
  const aa = 'input-text';
  
function Productsform(formTemplate) {
    console.log(formTemplate)
    console.log("uuuu");
  return(    
          
      <SellerAccount/>    
   );
}
  function Nestedifelse(service) {
    if (service === 'Belts') {
        console.log("clicked") 
      return(
        <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Belt}  onSubmit={onSubmit}/>
        </ScrollView></View>
      )
    }
    else if(service === 'Bracelets'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Bracelet}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Cufflinks'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Cufflinks}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Hats and Caps'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={HatsandCaps}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Fragrance'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Fragrance}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Pocket Squares'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={PocketSquare}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Rings'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Rings}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Socks'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Socks}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Sports Accessories'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Belt}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Sunglasses'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Glasses}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
    else if(service === 'Ties'){
        return(
          <View style = {{height:heightPercentageToDP("60%")}}>
          <ScrollView style = {{height:heightPercentageToDP("60%")}}>
        <DynamicForm formTemplate={Ties}  onSubmit={onSubmit}/>
        </ScrollView></View>
        )
    }
     
   
  }

  let [service, setService] = React.useState('');

  return (
    <NativeBaseProvider>
        <ScrollView style = {{height:heightPercentageToDP("50%")}}>
        <VStack alignItems="center" space={4}>
          <Select
            selectedValue={service}
            minWidth="375"
            accessibilityLabel="Select Your Product"
            placeholder="Select Information Type"
            _selectedItem={{
              bg: '#c89956',
              endIcon: <CheckIcon size="5" />,
            }}
            mt={5}
            onValueChange={itemValue => setService(itemValue)}>
            <Select.Item label="Belts" value="Belts" />
            <Select.Item label="Bracelets" value="Bracelets" />
            <Select.Item label="Cufflinks" value="Cufflinks" />
            <Select.Item label="Hats and Caps" value="Hats and Caps" />
            <Select.Item label="Fragrance" value="Fragrance" />
            <Select.Item label="Pocket Squares" value="Pocket Squares" />
            <Select.Item label="Rings" value="Rings" />
            <Select.Item label="Socks" value="Socks" />
            <Select.Item label="Sports Accessories" value="Sports Accessories" />
            <Select.Item label="Sunglasses" value="Sunglasses" />
            <Select.Item label="Ties" value="Ties" />
          </Select>
         </VStack>
        {Nestedifelse(service)}
        </ScrollView>
        
            
         
    </NativeBaseProvider>
  );
};

export default Accessories;
