import React from 'react'
import { View, Text } from 'react-native'

const Newbankaccount = () => {
    return (
        <View>
            <Text></Text>
        </View>
    )
}

export default Newbankaccount
