import React from 'react'
import { View, Text } from 'react-native'
import DiscountPromotions from './DiscountPromotions' 
const Upcomingpromotionsd = () => {
    return (
        
       <DiscountPromotions/>
    )
}

export default Upcomingpromotionsd
