import { View, Text } from 'react-native';
import React from 'react';

const check = () => {
  return (
    <View>
        <Text>qweer</Text>
    </View>
  );
};

export default check;
