import React from 'react'
import { View, Text } from 'react-native'

import {MainTools} from "../Data/MainTools"

const CategoryList = () => {
    return (
        <View>
            <Text>
                Hello World !
            </Text>
        </View>
    )
}

export default CategoryList
