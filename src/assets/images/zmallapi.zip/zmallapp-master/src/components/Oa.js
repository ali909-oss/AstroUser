import { View, Text } from 'react-native';
import React from 'react';

const Oa = () => {
  return (
    <View>
      <Text></Text>
    </View>
  );
};

export default Oa;
