import React from 'react'
import { View, Text } from 'react-native'

const Orders = () => {
    return (
        <View>
            <Text>Orders</Text>
        </View>
    )
}

export default Orders
