import React from 'react'
import { View, Text } from 'react-native'
import Orderstooltip from './Orderstooltip'

const In-Transit = () => {
    return (
       <Orderstooltip name = "In-Transit">
    )
}

export default In-Transit
