import React from 'react'
import { View, Text } from 'react-native'
import Bundledealsamain from './Bundledealsamain'
import Bundledealsmain from './Bundledealsmain'

const Bundledeals = () => {
    return ( 
           <Bundledealsamain/>
       
    )
}

export default Bundledeals
