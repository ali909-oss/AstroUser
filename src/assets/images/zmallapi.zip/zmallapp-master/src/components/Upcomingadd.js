import React from 'react'
import { View, Text } from 'react-native'
import OrdersButton from './Voucherbutton'
import Voucherscomp from './Voucherscomp'

const Upcomingadd = () => {
    return (
    
    <Voucherscomp/>
    )
}

export default Upcomingadd
