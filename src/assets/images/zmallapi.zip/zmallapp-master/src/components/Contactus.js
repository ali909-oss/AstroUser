import React from 'react'
import { View, Text } from 'react-native'

const Contactus = () => {
    return (
        <View style = {{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Contact Us</Text>
        </View>
    )
}

export default Contactus
